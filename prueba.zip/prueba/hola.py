import bpy

# Ruta al archivo .blend
ruta_archivo = "BASEmodel.blend"

# Cargar el archivo .blend
bpy.ops.wm.open_mainfile(filepath=ruta_archivo)

# Opcional: ajustar la vista de la cámara
bpy.ops.view3d.camera_to_view_selected()

# Renderizar la escena (opcional)
bpy.context.scene.render.filepath = "/tmp/render.png"  # Cambia la ruta según sea necesario
bpy.ops.render.render(write_still=True)

# Para visualizar en el viewport
bpy.ops.screen.area_split(direction='HORIZONTAL', factor=0.5)
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        area.spaces[0].region_3d.view_perspective = 'CAMERA'